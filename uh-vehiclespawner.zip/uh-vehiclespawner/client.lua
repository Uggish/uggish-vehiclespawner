Citizen.CreateThread(function()
    print("FORDONET HAR SPAWNAT")
    RequestModel(Config.bilmodel)
    while not HasModelLoaded(Config.bilmodel) do
        Citizen.Wait(0)
    end

    for i, position in ipairs(Config.spawnPositions) do
        if not IsPositionOccupied(position) then
            local vehicle = CreateVehicle(Config.bilmodel, position.x, position.y, position.z, Config.heading, true, false)
            SetVehicleOnGroundProperly(vehicle)

            if Config.CarsLocked then
                SetVehicleDoorsLocked(vehicle, 2) -- Lock the vehicle
            else
                SetVehicleDoorsLocked(vehicle, 0) -- Don't lock the vehicle
            end

            table.insert(Config.spawnedVehicles, vehicle)
        end
    end
end)


Citizen.CreateThread(function()
    while not NetworkIsPlayerActive(PlayerId()) do
    Citizen.Wait(0)
    end
    if Config.showBlips then
    for i = 1, #Config.Blips, 1 do
    local blipModel = Config.Blips[i].model or 398 -- Default to shopping cart icon if no model is specified
    local blipColor = Config.Blips[i].color or 2 -- Default to color 2 (green) if no color is specified
    local blipName = Config.Blips[i].name or "Cars" -- Default to "Cars" if no name is specified
    local uhBlip = AddBlipForCoord(Config.Blips[i].x, Config.Blips[i].y, Config.Blips[i].z)
    SetBlipAsShortRange(uhBlip, true)
    SetBlipColour(uhBlip, blipColor)
    SetBlipSprite(uhBlip, blipModel)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(blipName)
    EndTextCommandSetBlipName(uhBlip)
    end
    end
    end)