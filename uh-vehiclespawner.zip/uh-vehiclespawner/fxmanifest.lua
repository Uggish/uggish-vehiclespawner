fx_version 'cerulean'
game 'gta5'
lua54 'yes'
author 'Uggishhh#4551'
description 'Auto Bil Script.'
version '1.0.0'

client_scripts {
    'client.lua',
    'config.lua'
}

escrow_ignore {
    'config.lua',
    'readme.md',
    'README.md'
}

-- Discord https://discord.gg/ARqSTWMf
-- Tebex https://uggish-developing.tebex.io/
-- Discord Account Uggishhh#4551
-- /// UGGISH