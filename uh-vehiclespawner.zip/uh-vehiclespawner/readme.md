This script is a script on which a vehicle is spawned, only one vehicle is spawned, but if you want more to come, you restart the script e.g. a number of times until you see that they have been spawned. You can easily add more vehicles to the Config file. If you want the vehicles to change position, you can do so easily in the Config file. The positions that I added are just several examples. Create by Uggish Resources - Uggishhh#4551

-- You can easily add/remove as many vehicles as you want in the Config file.
-- You can easily change the blip name in the Config file.
-- You can easily change the blip model, color, etc. in the Config file.
-- You can easily change the car model in the Config file.
-- You can easily add more Blips with any name, blip model, color!
-- You can easily turn off the blip/blips not to be visible by setting "Config.showBlips" to false.