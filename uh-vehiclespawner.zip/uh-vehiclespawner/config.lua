Config = {}
Config.showBlips = true -- Om blipsen ska synas skriver du "true" / Enter "true" if you want blips to be visible
Config.CarsLocked = true -- false = not locked - true locked.
Config.Blips = {
    {x = 892.2, y = -42.03, z = 78.76, model = 1, color = 3, name = "Cars"}, -- Du kan ändra namn på blipen, färg, modell osv.
    -- You can change the name of the blip, color, model, etc. 
 }
Config.bilmodel = 'sanchez' -- You can change to other model, example primo...
Config.spawnPositions = {
    vector3(893.59, -38.98, 78.76), -- Example Position...
    vector3(892.2, -42.03, 78.76), -- Example Position...
    vector3(890.84, -45.41, 78.76) -- Example Position...
    }

Config.heading = 58.43 
Config.spawnedVehicles = {}  -- New configuration variable to store spawned vehicle information


